import { Check } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";

interface PricingCardProps {
  name: string;
  price: string;
  features: string[];
  productId: number;
  highlighted?: boolean;
}

export function PricingCard({ name, price, features, productId, highlighted }: PricingCardProps) {
  return (
    <div 
      className={`
        relative p-8 rounded-2xl border transition-all duration-300 group hover:-translate-y-2
        ${highlighted 
          ? "bg-card border-primary/50 shadow-2xl shadow-primary/10" 
          : "bg-card/50 border-white/5 hover:border-white/10 hover:bg-card"
        }
      `}
    >
      {highlighted && (
        <div className="absolute -top-4 left-1/2 -translate-x-1/2 px-4 py-1 rounded-full bg-gradient-to-r from-primary to-secondary text-xs font-bold text-white shadow-lg shadow-primary/20">
          MOST POPULAR
        </div>
      )}
      
      {/* Glow effect on hover */}
      <div className="absolute inset-0 bg-gradient-to-br from-primary/5 to-secondary/5 rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-300 -z-10" />

      <h3 className="font-display text-xl font-bold text-white mb-2">{name}</h3>
      <div className="flex items-baseline gap-1 mb-6">
        <span className="text-4xl font-bold text-white tracking-tight">{price}</span>
        <span className="text-muted-foreground text-sm">/mo</span>
      </div>

      <div className="space-y-4 mb-8">
        {features.map((feature, i) => (
          <div key={i} className="flex items-start gap-3">
            <div className="w-5 h-5 rounded-full bg-primary/10 flex items-center justify-center shrink-0 mt-0.5">
              <Check className="w-3 h-3 text-primary" />
            </div>
            <span className="text-sm text-muted-foreground">{feature}</span>
          </div>
        ))}
      </div>

      <Link href={`/order?product=${productId}`}>
        <Button 
          className={`w-full h-12 rounded-xl font-semibold transition-all duration-300 ${
            highlighted 
              ? "bg-gradient-to-r from-primary to-secondary hover:shadow-lg hover:shadow-primary/25 border-0" 
              : "bg-white/5 hover:bg-white/10 text-white border-transparent"
          }`}
        >
          Order Now
        </Button>
      </Link>
    </div>
  );
}
