import { Navbar } from "@/components/Navbar";
import { Footer } from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { motion } from "framer-motion";
import { Server, Shield, Zap, Globe, Cpu, Clock } from "lucide-react";
import { useAuth } from "@/hooks/use-auth";

export default function Home() {
  const { user } = useAuth();

  const features = [
    {
      icon: <Zap className="w-6 h-6 text-yellow-400" />,
      title: "Instant Setup",
      desc: "Your server is deployed automatically within seconds after payment confirmation."
    },
    {
      icon: <Shield className="w-6 h-6 text-green-400" />,
      title: "DDoS Protection",
      desc: "Advanced mitigation keeps your services online even during massive attacks."
    },
    {
      icon: <Cpu className="w-6 h-6 text-blue-400" />,
      title: "High Performance",
      desc: "Powered by latest generation Ryzen processors and NVMe SSD storage."
    },
    {
      icon: <Globe className="w-6 h-6 text-purple-400" />,
      title: "Global Locations",
      desc: "Servers available in multiple regions for lowest possible latency."
    },
    {
      icon: <Clock className="w-6 h-6 text-red-400" />,
      title: "99.9% Uptime",
      desc: "Enterprise-grade infrastructure ensures your services stay online 24/7."
    },
    {
      icon: <Server className="w-6 h-6 text-cyan-400" />,
      title: "Full Access",
      desc: "Get full control with root access for VPS and Pterodactyl panel for MC."
    }
  ];

  return (
    <div className="min-h-screen bg-background text-foreground overflow-x-hidden">
      <Navbar />

      {/* Hero Section */}
      <section className="relative pt-32 pb-20 lg:pt-48 lg:pb-32 px-4 overflow-hidden">
        {/* Background Glow */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full max-w-7xl h-[500px] bg-primary/20 blur-[120px] rounded-full opacity-50 -z-10 pointer-events-none" />

        <div className="max-w-7xl mx-auto text-center relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white/5 border border-white/10 mb-8 backdrop-blur-sm">
              <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-secondary opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-secondary"></span>
              </span>
              <span className="text-xs font-medium text-secondary tracking-wide uppercase">New High Performance Nodes Available</span>
            </div>

            <h1 className="font-display text-5xl md:text-7xl font-bold mb-6 tracking-tight">
              Power Your Projects with <br/>
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary to-secondary text-glow">
                Next-Gen Hosting
              </span>
            </h1>

            <p className="text-muted-foreground text-lg md:text-xl max-w-2xl mx-auto mb-10 leading-relaxed">
              Experience blazing fast VPS and Minecraft servers with enterprise-grade protection. 
              Deploy instantly and scale as you grow.
            </p>

            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <Link href="/pricing">
                <Button size="lg" className="h-14 px-8 rounded-full bg-gradient-to-r from-primary to-secondary hover:shadow-lg hover:shadow-primary/25 border-0 text-base font-semibold w-full sm:w-auto">
                  View Plans
                </Button>
              </Link>
              <Link href={user ? "/client" : "/api/login"}>
                <Button variant="outline" size="lg" className="h-14 px-8 rounded-full border-white/10 hover:bg-white/5 text-base font-semibold w-full sm:w-auto">
                  Client Area
                </Button>
              </Link>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Features Grid */}
      <section className="py-24 bg-black/20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="font-display text-3xl md:text-4xl font-bold mb-4">Why Choose BazarNodes?</h2>
            <p className="text-muted-foreground">Built for performance, reliability, and ease of use.</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {features.map((feature, idx) => (
              <motion.div
                key={idx}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: idx * 0.1 }}
                className="p-6 rounded-2xl bg-card border border-white/5 hover:border-primary/50 transition-colors duration-300 group"
              >
                <div className="w-12 h-12 rounded-lg bg-white/5 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform duration-300">
                  {feature.icon}
                </div>
                <h3 className="font-display text-xl font-bold mb-2 group-hover:text-primary transition-colors">{feature.title}</h3>
                <p className="text-muted-foreground text-sm leading-relaxed">{feature.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-24 relative overflow-hidden">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="bg-gradient-to-br from-primary/20 to-secondary/20 rounded-3xl p-8 md:p-16 text-center border border-white/10 backdrop-blur-md">
            <h2 className="font-display text-3xl md:text-5xl font-bold mb-6">Ready to Start?</h2>
            <p className="text-muted-foreground max-w-xl mx-auto mb-8 text-lg">
              Join thousands of happy customers hosting their communities and projects with us today.
            </p>
            <Link href="/pricing">
              <Button size="lg" className="h-14 px-10 rounded-full bg-white text-black hover:bg-white/90 font-bold">
                Get Started Now
              </Button>
            </Link>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
