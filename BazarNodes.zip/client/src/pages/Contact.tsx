import { Navbar } from "@/components/Navbar";
import { Footer } from "@/components/Footer";
import { Mail, MessageCircle } from "lucide-react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

export default function Contact() {
  return (
    <div className="min-h-screen bg-background text-foreground">
      <Navbar />
      <main className="pt-32 pb-24 px-4 sm:px-6 lg:px-8">
        <div className="max-w-3xl mx-auto text-center">
          <h1 className="font-display text-4xl font-bold mb-8">Get in Touch</h1>
          <p className="text-muted-foreground text-lg mb-12">
            Have questions? We're here to help. Reach out to us via Email or Discord.
          </p>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <Card className="bg-card border-white/5 hover:border-primary/50 transition-colors p-8">
              <div className="w-12 h-12 bg-primary/10 rounded-xl flex items-center justify-center mx-auto mb-4">
                <Mail className="w-6 h-6 text-primary" />
              </div>
              <h3 className="font-bold text-xl mb-2">Email Support</h3>
              <p className="text-muted-foreground mb-6">For business inquiries and general questions</p>
              <Button variant="outline" className="w-full border-white/10 hover:bg-white/5">
                support@bazarnodes.com
              </Button>
            </Card>

            <Card className="bg-card border-white/5 hover:border-[#5865F2]/50 transition-colors p-8">
              <div className="w-12 h-12 bg-[#5865F2]/10 rounded-xl flex items-center justify-center mx-auto mb-4">
                <MessageCircle className="w-6 h-6 text-[#5865F2]" />
              </div>
              <h3 className="font-bold text-xl mb-2">Discord Community</h3>
              <p className="text-muted-foreground mb-6">Join our community for fast support</p>
              <a href="https://dsc.gg/BazarNodes" target="_blank" rel="noopener noreferrer" className="block w-full">
                <Button className="w-full bg-[#5865F2] hover:bg-[#5865F2]/90 text-white">
                  Join Discord
                </Button>
              </a>
            </Card>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
}
