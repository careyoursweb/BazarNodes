import { Navbar } from "@/components/Navbar";
import { useAuth } from "@/hooks/use-auth";
import { useTickets, useCreateTicket, useTicketMessages, useCreateTicketMessage } from "@/hooks/use-tickets";
import { Link } from "wouter";
import { 
  ArrowLeft, Plus, MessageSquare, Send, Loader2
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { useState, useEffect, useRef } from "react";
import { useToast } from "@/hooks/use-toast";
import { Badge } from "@/components/ui/badge";
import { redirectToLogin } from "@/lib/auth-utils";

export default function Tickets() {
  const { user, isLoading } = useAuth();
  const { data: tickets, isLoading: ticketsLoading } = useTickets();
  const [selectedTicketId, setSelectedTicketId] = useState<number | null>(null);
  const { toast } = useToast();

  useEffect(() => {
    if (!isLoading && !user) {
      redirectToLogin(toast as any);
    }
  }, [user, isLoading, toast]);

  if (isLoading || !user) return null;

  return (
    <div className="min-h-screen bg-background text-foreground">
      <Navbar />
      
      <main className="pt-32 pb-24 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="flex items-center justify-between mb-8">
            <div className="flex items-center gap-4">
              <Link href="/client">
                <Button variant="ghost" size="icon">
                  <ArrowLeft className="w-5 h-5" />
                </Button>
              </Link>
              <h1 className="font-display text-3xl font-bold">Support Tickets</h1>
            </div>
            <CreateTicketDialog />
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 h-[600px]">
            {/* Ticket List */}
            <Card className="bg-card border-white/5 col-span-1 overflow-hidden flex flex-col">
              <CardHeader className="pb-3 border-b border-white/5">
                <CardTitle className="text-lg">Your Tickets</CardTitle>
              </CardHeader>
              <div className="flex-1 overflow-y-auto p-4 space-y-2">
                {ticketsLoading ? (
                  <div className="text-center py-4"><Loader2 className="animate-spin mx-auto text-muted-foreground" /></div>
                ) : tickets?.length === 0 ? (
                  <div className="text-center py-8 text-muted-foreground">No tickets found.</div>
                ) : (
                  tickets?.map(ticket => (
                    <button
                      key={ticket.id}
                      onClick={() => setSelectedTicketId(ticket.id)}
                      className={`w-full text-left p-4 rounded-xl border transition-all ${
                        selectedTicketId === ticket.id 
                          ? "bg-primary/10 border-primary/30" 
                          : "bg-background/50 border-white/5 hover:bg-white/5"
                      }`}
                    >
                      <div className="flex justify-between items-start mb-1">
                        <span className="font-medium truncate pr-2">{ticket.subject}</span>
                        <Badge variant="secondary" className="text-[10px] h-5">{ticket.status}</Badge>
                      </div>
                      <p className="text-xs text-muted-foreground capitalize">{ticket.category.replace('_', ' ')}</p>
                    </button>
                  ))
                )}
              </div>
            </Card>

            {/* Chat Area */}
            <Card className="bg-card border-white/5 col-span-1 lg:col-span-2 overflow-hidden flex flex-col">
              {selectedTicketId ? (
                <TicketChat ticketId={selectedTicketId} userId={user.id} />
              ) : (
                <div className="flex-1 flex flex-col items-center justify-center text-muted-foreground">
                  <MessageSquare className="w-12 h-12 mb-4 opacity-20" />
                  <p>Select a ticket to view conversation</p>
                </div>
              )}
            </Card>
          </div>
        </div>
      </main>
    </div>
  );
}

function CreateTicketDialog() {
  const [open, setOpen] = useState(false);
  const { mutate: createTicket, isPending } = useCreateTicket();
  const { toast } = useToast();
  const { user } = useAuth();
  
  const [formData, setFormData] = useState({
    subject: "",
    category: "support",
    message: "" // Initial message
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;

    createTicket(
      { 
        userId: user.id, // Backend should enforce this from session, id is string
        subject: formData.subject,
        category: formData.category
      },
      {
        onSuccess: (ticket) => {
          // Ideally we would also post the first message here
          toast({ title: "Ticket Created", description: "Our team will respond shortly." });
          setOpen(false);
          setFormData({ subject: "", category: "support", message: "" });
        },
        onError: () => {
          toast({ title: "Error", description: "Failed to create ticket", variant: "destructive" as "destructive" });
        }
      }
    );
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button className="bg-primary hover:bg-primary/90">
          <Plus className="w-4 h-4 mr-2" /> New Ticket
        </Button>
      </DialogTrigger>
      <DialogContent className="bg-card border-white/10 text-foreground">
        <DialogHeader>
          <DialogTitle>Open New Support Ticket</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4 pt-4">
          <div className="space-y-2">
            <label className="text-sm font-medium">Subject</label>
            <Input 
              required
              placeholder="Brief description of issue" 
              className="bg-background border-white/10"
              value={formData.subject}
              onChange={e => setFormData({...formData, subject: e.target.value})}
            />
          </div>
          <div className="space-y-2">
            <label className="text-sm font-medium">Category</label>
            <Select 
              value={formData.category} 
              onValueChange={val => setFormData({...formData, category: val})}
            >
              <SelectTrigger className="bg-background border-white/10">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="buy_vps">Buy VPS</SelectItem>
                <SelectItem value="buy_mc">Buy Minecraft Server</SelectItem>
                <SelectItem value="payment">Payment Issue</SelectItem>
                <SelectItem value="support">Technical Support</SelectItem>
                <SelectItem value="other">Other</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <Button type="submit" className="w-full" disabled={isPending}>
            {isPending ? <Loader2 className="animate-spin" /> : "Create Ticket"}
          </Button>
        </form>
      </DialogContent>
    </Dialog>
  );
}

function TicketChat({ ticketId, userId }: { ticketId: number; userId: string }) {
  const { data: messages, isLoading } = useTicketMessages(ticketId);
  const { mutate: sendMessage, isPending } = useCreateTicketMessage();
  const [message, setMessage] = useState("");
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    if (!message.trim()) return;
    sendMessage(
      { ticketId, message },
      { onSuccess: () => setMessage("") }
    );
  };

  return (
    <>
      <div className="flex-1 overflow-y-auto p-4 space-y-4" ref={scrollRef}>
        {isLoading ? (
          <div className="flex justify-center"><Loader2 className="animate-spin text-primary" /></div>
        ) : (
          messages?.map((msg) => {
            const isMe = String(msg.userId) === String(userId);
            return (
              <div key={msg.id} className={`flex ${isMe ? 'justify-end' : 'justify-start'}`}>
                <div className={`max-w-[80%] p-3 rounded-2xl text-sm ${
                  isMe ? 'bg-primary text-white rounded-br-none' : 'bg-white/10 text-foreground rounded-bl-none'
                }`}>
                  {msg.message}
                </div>
              </div>
            );
          })
        )}
      </div>
      <div className="p-4 border-t border-white/5 bg-background/50">
        <form onSubmit={handleSend} className="flex gap-2">
          <Input 
            value={message}
            onChange={e => setMessage(e.target.value)}
            placeholder="Type your message..."
            className="bg-background border-white/10"
          />
          <Button type="submit" size="icon" disabled={isPending || !message.trim()}>
            {isPending ? <Loader2 className="animate-spin w-4 h-4" /> : <Send className="w-4 h-4" />}
          </Button>
        </form>
      </div>
    </>
  );
}
