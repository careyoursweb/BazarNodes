import { Navbar } from "@/components/Navbar";
import { Footer } from "@/components/Footer";

export default function Status() {
  const systems = [
    { name: "Web Dashboard", status: "Operational", color: "bg-green-500" },
    { name: "Minecraft Nodes (Asia)", status: "Operational", color: "bg-green-500" },
    { name: "Minecraft Nodes (Europe)", status: "Operational", color: "bg-green-500" },
    { name: "VPS Nodes (US)", status: "Operational", color: "bg-green-500" },
    { name: "Billing System", status: "Operational", color: "bg-green-500" },
    { name: "Support API", status: "Operational", color: "bg-green-500" },
  ];

  return (
    <div className="min-h-screen bg-background text-foreground">
      <Navbar />
      <main className="pt-32 pb-24 px-4 sm:px-6 lg:px-8">
        <div className="max-w-3xl mx-auto">
          <div className="text-center mb-12">
            <h1 className="font-display text-3xl md:text-5xl font-bold mb-4">System Status</h1>
            <p className="text-muted-foreground">Real-time status of our hosting infrastructure.</p>
          </div>

          <div className="grid gap-4">
            <div className="p-6 rounded-2xl bg-card border border-white/5 flex items-center justify-between">
              <span className="font-semibold text-lg">Overall Status</span>
              <div className="flex items-center gap-2">
                <span className="w-3 h-3 rounded-full bg-green-500 animate-pulse"></span>
                <span className="text-green-500 font-bold">All Systems Operational</span>
              </div>
            </div>

            <div className="grid gap-3">
              {systems.map((s, i) => (
                <div key={i} className="p-4 rounded-xl bg-white/5 border border-white/5 flex items-center justify-between">
                  <span className="text-sm font-medium">{s.name}</span>
                  <div className="flex items-center gap-2">
                    <span className={`w-2 h-2 rounded-full ${s.color}`}></span>
                    <span className="text-xs font-medium">{s.status}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
}
