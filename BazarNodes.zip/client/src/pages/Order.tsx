import { Navbar } from "@/components/Navbar";
import { Footer } from "@/components/Footer";
import { useLocation } from "wouter";
import { useProducts, useProduct } from "@/hooks/use-products";
import { useCreateOrder } from "@/hooks/use-orders";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useAuth } from "@/hooks/use-auth";
import { Loader2, QrCode, CheckCircle, AlertCircle } from "lucide-react";
import { useState, useEffect } from "react";
import { useToast } from "@/hooks/use-toast";
import { redirectToLogin } from "@/lib/auth-utils";
import upiQrPath from "@assets/IMG_20250801_152638_1767179617980.png";

export default function Order() {
  const [location, setLocation] = useLocation();
  const searchParams = new URLSearchParams(window.location.search);
  const productIdParam = searchParams.get("product");
  
  const [selectedProductId, setSelectedProductId] = useState<string>(productIdParam || "");
  const { data: products } = useProducts();
  const { data: selectedProduct } = useProduct(Number(selectedProductId));
  const { user, authLoading } = useAuth() as any; // Using authLoading from useAuth
  const { mutate: createOrder, isPending: isCreating } = useCreateOrder();
  const { toast } = useToast();

  // Redirect if not logged in
  useEffect(() => {
    if (!authLoading && !user) {
      redirectToLogin(toast as any);
    }
  }, [user, authLoading, toast]);

  const handleOrder = () => {
    if (!selectedProductId) return;
    
    createOrder(
      { 
        productId: Number(selectedProductId),
        userId: user?.id // Backend should use session user, id is string from Replit Auth
      }, 
      {
        onSuccess: () => {
          toast({
            title: "Order Placed Successfully",
            description: "Please complete the payment to activate your service.",
          });
          setLocation("/client");
        },
        onError: (error) => {
          toast({
            title: "Order Failed",
            description: error.message,
            variant: "destructive" as "destructive"
          });
        }
      }
    );
  };

  if (authLoading) return <div className="h-screen flex items-center justify-center bg-background"><Loader2 className="animate-spin text-primary" /></div>;
  if (!user) return null; // Redirect handled by useEffect

  return (
    <div className="min-h-screen bg-background text-foreground">
      <Navbar />
      
      <main className="pt-32 pb-24 px-4 sm:px-6 lg:px-8">
        <div className="max-w-3xl mx-auto">
          <div className="text-center mb-12">
            <h1 className="font-display text-3xl md:text-5xl font-bold mb-4">Complete Your Order</h1>
            <p className="text-muted-foreground">Review your selection and proceed to payment.</p>
          </div>

          <div className="grid gap-8">
            {/* Product Selection */}
            <Card className="bg-card border-white/5">
              <CardHeader>
                <CardTitle>Service Configuration</CardTitle>
                <CardDescription>Select the plan you wish to purchase</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <label className="text-sm font-medium">Select Plan</label>
                  <Select 
                    value={selectedProductId} 
                    onValueChange={(val) => setSelectedProductId(val)}
                  >
                    <SelectTrigger className="w-full h-12 bg-background border-white/10">
                      <SelectValue placeholder="Choose a plan..." />
                    </SelectTrigger>
                    <SelectContent>
                      {products?.map((p) => (
                        <SelectItem key={p.id} value={p.id.toString()}>
                          {p.name} - {p.price}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>

                  {selectedProduct && (
                    <div className="mt-6 p-4 rounded-xl bg-primary/5 border border-primary/20">
                      <div className="flex justify-between items-center mb-2">
                        <span className="font-semibold text-white">{selectedProduct.name}</span>
                        <span className="font-bold text-primary text-lg">{selectedProduct.price}</span>
                      </div>
                      <ul className="space-y-1">
                        {selectedProduct.features.map((f, i) => (
                          <li key={i} className="text-sm text-muted-foreground flex items-center gap-2">
                            <CheckCircle className="w-3 h-3 text-primary" /> {f}
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>

            {/* Payment Info */}
            <Card className="bg-card border-white/5">
              <CardHeader>
                <CardTitle>Payment Method</CardTitle>
                <CardDescription>Scan the QR code to pay via UPI</CardDescription>
              </CardHeader>
              <CardContent className="flex flex-col items-center py-6">
                <div className="w-64 h-64 bg-white rounded-xl p-4 mb-6 shadow-xl overflow-hidden flex items-center justify-center">
                  <img src={upiQrPath} alt="UPI QR Code" className="w-full h-full object-contain" />
                </div>
                
                <div className="text-center space-y-2 mb-8">
                  <p className="font-mono text-xl font-bold bg-white/5 px-6 py-3 rounded-lg text-primary border border-primary/20 tracking-wider">aarjvmishra@fam</p>
                  <p className="text-sm text-muted-foreground">Scan with any UPI app (GPay, PhonePe, Paytm)</p>
                </div>

                <div className="w-full p-4 rounded-lg bg-yellow-500/10 border border-yellow-500/20 flex items-start gap-3 mb-6">
                  <AlertCircle className="w-5 h-5 text-yellow-500 shrink-0 mt-0.5" />
                  <p className="text-sm text-yellow-200/80">
                    After payment, your service will be activated manually. Please open a ticket if it takes longer than 24 hours.
                  </p>
                </div>

                <Button 
                  size="lg" 
                  className="w-full h-14 bg-primary hover:bg-primary/90 text-lg font-bold"
                  disabled={!selectedProductId || isCreating}
                  onClick={handleOrder}
                >
                  {isCreating ? (
                    <>
                      <Loader2 className="w-5 h-5 mr-2 animate-spin" /> Processing...
                    </>
                  ) : (
                    "Confirm Order"
                  )}
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}
