import { Navbar } from "@/components/Navbar";
import { Footer } from "@/components/Footer";
import { PricingCard } from "@/components/PricingCard";
import { useProducts } from "@/hooks/use-products";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { motion } from "framer-motion";
import { Loader2 } from "lucide-react";

export default function Pricing() {
  const { data: products, isLoading } = useProducts();

  const vpsProducts = products?.filter(p => p.type === 'vps') || [];
  const mcProducts = products?.filter(p => p.type === 'minecraft') || [];

  return (
    <div className="min-h-screen bg-background text-foreground">
      <Navbar />
      
      <main className="pt-32 pb-24 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h1 className="font-display text-4xl md:text-6xl font-bold mb-6">Simple, Transparent Pricing</h1>
            <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
              Choose the perfect plan for your needs. Upgrade or downgrade at any time.
            </p>
          </div>

          {isLoading ? (
            <div className="flex justify-center items-center h-64">
              <Loader2 className="w-10 h-10 animate-spin text-primary" />
            </div>
          ) : (
            <Tabs defaultValue="minecraft" className="w-full">
              <div className="flex justify-center mb-12">
                <TabsList className="bg-white/5 p-1 rounded-full border border-white/5">
                  <TabsTrigger 
                    value="minecraft"
                    className="rounded-full px-8 py-2.5 data-[state=active]:bg-primary data-[state=active]:text-white font-medium transition-all"
                  >
                    Minecraft Hosting
                  </TabsTrigger>
                  <TabsTrigger 
                    value="vps"
                    className="rounded-full px-8 py-2.5 data-[state=active]:bg-primary data-[state=active]:text-white font-medium transition-all"
                  >
                    VPS Hosting
                  </TabsTrigger>
                </TabsList>
              </div>

              <TabsContent value="minecraft">
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                  {mcProducts.map((product, i) => (
                    <motion.div
                      key={product.id}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: i * 0.1 }}
                    >
                      <PricingCard
                        name={product.name}
                        price={product.price}
                        features={product.features}
                        productId={product.id}
                        highlighted={i === 1} // Highlight middle plan
                      />
                    </motion.div>
                  ))}
                </div>
              </TabsContent>

              <TabsContent value="vps">
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                  {vpsProducts.map((product, i) => (
                    <motion.div
                      key={product.id}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: i * 0.1 }}
                    >
                      <PricingCard
                        name={product.name}
                        price={product.price}
                        features={product.features}
                        productId={product.id}
                        highlighted={i === 1}
                      />
                    </motion.div>
                  ))}
                </div>
              </TabsContent>
            </Tabs>
          )}
        </div>
      </main>

      <Footer />
    </div>
  );
}
