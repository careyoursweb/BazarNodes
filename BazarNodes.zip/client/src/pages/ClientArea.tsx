import { Navbar } from "@/components/Navbar";
import { useAuth } from "@/hooks/use-auth";
import { useOrders } from "@/hooks/use-orders";
import { Link, useLocation } from "wouter";
import { 
  LayoutDashboard, Server, CreditCard, LifeBuoy, 
  LogOut, Box, Clock, User
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { redirectToLogin } from "@/lib/auth-utils";
import { useEffect } from "react";
import { useToast } from "@/hooks/use-toast";

export default function ClientArea() {
  const { user, isLoading, logout } = useAuth();
  const { data: orders, isLoading: ordersLoading } = useOrders();
  const [location] = useLocation();
  const { toast } = useToast();

  useEffect(() => {
    if (!isLoading && !user) {
      redirectToLogin(toast as any);
    }
  }, [user, isLoading, toast]);

  if (isLoading || !user) return null;

  const Sidebar = () => (
    <div className="w-full lg:w-64 shrink-0 space-y-2">
      <div className="p-6 bg-card rounded-2xl border border-white/5 mb-6">
        <div className="flex items-center gap-3 mb-4">
          <div className="w-10 h-10 rounded-full bg-primary/20 flex items-center justify-center text-primary font-bold">
            {(user?.firstName || user?.email || "U").charAt(0).toUpperCase()}
          </div>
          <div className="overflow-hidden">
            <h3 className="font-bold truncate">{user?.firstName || user?.email}</h3>
            <p className="text-xs text-muted-foreground truncate">{user?.email || "No email"}</p>
          </div>
        </div>
        <Button variant="outline" size="sm" className="w-full border-white/10 hover:bg-white/5" onClick={() => logout()}>
          <LogOut className="w-3 h-3 mr-2" /> Logout
        </Button>
      </div>

      <nav className="space-y-1">
        <Link href="/client">
          <Button variant="ghost" className={`w-full justify-start ${location === "/client" ? "bg-primary/10 text-primary" : "text-muted-foreground"}`}>
            <LayoutDashboard className="w-4 h-4 mr-3" /> Dashboard
          </Button>
        </Link>
        <Link href="/client/tickets">
          <Button variant="ghost" className={`w-full justify-start ${location.includes("tickets") ? "bg-primary/10 text-primary" : "text-muted-foreground"}`}>
            <LifeBuoy className="w-4 h-4 mr-3" /> Support Tickets
          </Button>
        </Link>
        <Link href="/pricing">
          <Button variant="ghost" className="w-full justify-start text-muted-foreground">
            <CreditCard className="w-4 h-4 mr-3" /> Order New Service
          </Button>
        </Link>
      </nav>
    </div>
  );

  return (
    <div className="min-h-screen bg-background text-foreground">
      <Navbar />
      
      <main className="pt-32 pb-24 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto flex flex-col lg:flex-row gap-8">
          <Sidebar />

          <div className="flex-1 space-y-8">
            <h1 className="font-display text-3xl font-bold">Dashboard</h1>

            {/* Stats Grid */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <Card className="bg-card border-white/5">
                <CardHeader className="flex flex-row items-center justify-between pb-2">
                  <CardTitle className="text-sm font-medium text-muted-foreground">Active Services</CardTitle>
                  <Server className="w-4 h-4 text-primary" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{orders?.filter(o => o.status === 'active').length || 0}</div>
                </CardContent>
              </Card>
              <Card className="bg-card border-white/5">
                <CardHeader className="flex flex-row items-center justify-between pb-2">
                  <CardTitle className="text-sm font-medium text-muted-foreground">Pending Orders</CardTitle>
                  <Clock className="w-4 h-4 text-yellow-500" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{orders?.filter(o => o.status === 'pending').length || 0}</div>
                </CardContent>
              </Card>
              <Card className="bg-card border-white/5">
                <CardHeader className="flex flex-row items-center justify-between pb-2">
                  <CardTitle className="text-sm font-medium text-muted-foreground">Total Orders</CardTitle>
                  <Box className="w-4 h-4 text-blue-500" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{orders?.length || 0}</div>
                </CardContent>
              </Card>
            </div>

            {/* Recent Orders */}
            <Card className="bg-card border-white/5">
              <CardHeader>
                <CardTitle>Your Services</CardTitle>
              </CardHeader>
              <CardContent>
                {ordersLoading ? (
                  <div className="space-y-4">
                    {[1, 2].map(i => <div key={i} className="h-16 bg-white/5 rounded-lg animate-pulse" />)}
                  </div>
                ) : orders && orders.length > 0 ? (
                  <div className="space-y-4">
                    {orders.map((order) => (
                      <div key={order.id} className="flex items-center justify-between p-4 rounded-xl bg-background/50 border border-white/5">
                        <div className="flex items-center gap-4">
                          <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
                            <Box className="w-5 h-5 text-primary" />
                          </div>
                          <div>
                            <p className="font-semibold">Service #{order.id}</p>
                            <p className="text-sm text-muted-foreground">Product ID: {order.productId}</p>
                          </div>
                        </div>
                        <Badge 
                          className={`
                            ${order.status === 'active' ? 'bg-green-500/10 text-green-500 hover:bg-green-500/20' : ''}
                            ${order.status === 'pending' ? 'bg-yellow-500/10 text-yellow-500 hover:bg-yellow-500/20' : ''}
                            ${order.status === 'suspended' ? 'bg-red-500/10 text-red-500 hover:bg-red-500/20' : ''}
                          `}
                        >
                          {order.status.toUpperCase()}
                        </Badge>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-12">
                    <Box className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                    <h3 className="text-lg font-medium mb-2">No services yet</h3>
                    <p className="text-muted-foreground mb-4">Start your journey by ordering a service.</p>
                    <Link href="/pricing">
                      <Button variant="outline">Browse Plans</Button>
                    </Link>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
    </div>
  );
}
