import { Navbar } from "@/components/Navbar";
import { Footer } from "@/components/Footer";

export default function Refund() {
  return (
    <div className="min-h-screen bg-background text-foreground">
      <Navbar />
      <main className="pt-32 pb-24 px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto prose prose-invert">
          <h1 className="font-display">Refund Policy</h1>
          
          <h3>3-Day Money Back Guarantee</h3>
          <p>If you are not satisfied with our services for any reason, you may request a full refund within 3 days of your initial purchase.</p>

          <h3>Eligibility</h3>
          <p>Refunds are only available for first-time purchases. Renewals and addon services are non-refundable.</p>

          <h3>Processing Time</h3>
          <p>Refunds are typically processed within 5-7 business days back to the original payment method.</p>
          
          <h3>Exceptions</h3>
          <p>Accounts terminated for Terms of Service violations are not eligible for refunds.</p>
        </div>
      </main>
      <Footer />
    </div>
  );
}
