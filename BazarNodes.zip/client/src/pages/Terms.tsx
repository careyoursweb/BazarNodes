import { Navbar } from "@/components/Navbar";
import { Footer } from "@/components/Footer";

export default function Terms() {
  return (
    <div className="min-h-screen bg-background text-foreground">
      <Navbar />
      <main className="pt-32 pb-24 px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto prose prose-invert">
          <h1 className="font-display">Terms of Service</h1>
          <p className="lead">Last updated: {new Date().toLocaleDateString()}</p>
          
          <h3>1. Acceptance of Terms</h3>
          <p>By accessing and using BazarNodes, you accept and agree to be bound by the terms and provision of this agreement.</p>

          <h3>2. Service Availability</h3>
          <p>We strive to maintain 99.9% uptime for all services. However, occasional maintenance may be required. We will provide advance notice whenever possible.</p>

          <h3>3. Acceptable Use</h3>
          <p>Users must not use our services for any illegal activities, including but not limited to: DDoS attacks, spamming, phishing, or hosting illegal content.</p>

          <h3>4. Payments and Billing</h3>
          <p>Services are billed on a monthly prepaid basis. Failure to pay may result in service suspension.</p>
        </div>
      </main>
      <Footer />
    </div>
  );
}
