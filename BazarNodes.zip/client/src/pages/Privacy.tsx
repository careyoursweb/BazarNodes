import { Navbar } from "@/components/Navbar";
import { Footer } from "@/components/Footer";

export default function Privacy() {
  return (
    <div className="min-h-screen bg-background text-foreground">
      <Navbar />
      <main className="pt-32 pb-24 px-4 sm:px-6 lg:px-8">
        <div className="max-w-3xl mx-auto prose prose-invert">
          <h1 className="font-display text-3xl md:text-5xl font-bold mb-8">Privacy Policy</h1>
          <p>At BazarNodes, we take your privacy seriously. This policy describes how we collect and use your data.</p>
          <h3>1. Data Collection</h3>
          <p>We collect your name, email, and IP address for account management and security purposes.</p>
          <h3>2. Data Usage</h3>
          <p>Your data is used solely to provide services, process payments, and improve our platform.</p>
          <h3>3. Data Sharing</h3>
          <p>We never sell your personal information to third parties.</p>
        </div>
      </main>
      <Footer />
    </div>
  );
}
