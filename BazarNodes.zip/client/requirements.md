## Packages
framer-motion | Page transitions and scroll animations
clsx | Class name utility for conditional styling
tailwind-merge | Utility to merge tailwind classes properly

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  display: ["var(--font-display)"],
  body: ["var(--font-body)"],
}
