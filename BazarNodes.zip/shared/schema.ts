import { pgTable, text, serial, integer, boolean, timestamp, jsonb, varchar } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { users as authUsers } from "./models/auth";

export * from "./models/auth";

export const products = pgTable("products", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  type: text("type").notNull(), // 'vps' or 'minecraft'
  price: text("price").notNull(),
  description: text("description").notNull(),
  features: jsonb("features").$type<string[]>().notNull(),
});

export const orders = pgTable("orders", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").references(() => authUsers.id).notNull(),
  productId: integer("product_id").references(() => products.id).notNull(),
  status: text("status").notNull().default("pending"), // pending, active, suspended
  createdAt: timestamp("created_at").defaultNow(),
});

export const tickets = pgTable("tickets", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").references(() => authUsers.id).notNull(),
  subject: text("subject").notNull(),
  category: text("category").notNull(), // buy_vps, buy_mc, payment, support, other
  status: text("status").notNull().default("open"), // open, closed, answered
  createdAt: timestamp("created_at").defaultNow(),
});

export const ticketMessages = pgTable("ticket_messages", {
  id: serial("id").primaryKey(),
  ticketId: integer("ticket_id").references(() => tickets.id).notNull(),
  userId: varchar("user_id").references(() => authUsers.id).notNull(), // Sender
  message: text("message").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertProductSchema = createInsertSchema(products).omit({ id: true });
export const insertOrderSchema = createInsertSchema(orders).omit({ id: true, createdAt: true, status: true });
export const insertTicketSchema = createInsertSchema(tickets).omit({ id: true, createdAt: true, status: true });
export const insertTicketMessageSchema = createInsertSchema(ticketMessages).omit({ id: true, createdAt: true });

export type Product = typeof products.$inferSelect;
export type Order = typeof orders.$inferSelect;
export type Ticket = typeof tickets.$inferSelect;
export type TicketMessage = typeof ticketMessages.$inferSelect;
