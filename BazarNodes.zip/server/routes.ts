import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";
import { setupAuth, registerAuthRoutes, isAuthenticated } from "./replit_integrations/auth";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  // Setup Authentication
  await setupAuth(app);
  registerAuthRoutes(app);

  // --- API Routes ---

  // Products (Public)
  app.get(api.products.list.path, async (req, res) => {
    const products = await storage.getProducts();
    res.json(products);
  });

  app.get(api.products.get.path, async (req, res) => {
    const product = await storage.getProduct(Number(req.params.id));
    if (!product) return res.status(404).json({ message: "Product not found" });
    res.json(product);
  });

  // Protected Routes
  
  // Orders
  app.get(api.orders.list.path, isAuthenticated, async (req: any, res) => {
    const orders = await storage.getOrders(req.user.claims.sub);
    res.json(orders);
  });

  app.post(api.orders.create.path, isAuthenticated, async (req: any, res) => {
    try {
      // Ensure the user ID from the session is used
      const orderData = {
        ...req.body,
        userId: req.user.id || req.user.claims?.sub 
      };
      const input = api.orders.create.input.parse(orderData);
      const order = await storage.createOrder(input);
      res.status(201).json(order);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({
          message: err.errors[0].message,
          field: err.errors[0].path.join('.'),
        });
      }
      throw err;
    }
  });

  // Tickets
  app.get(api.tickets.list.path, isAuthenticated, async (req: any, res) => {
    // If admin, they can see all tickets. If not, only their own.
    const userEmail = req.user?.claims?.email;
    const isAdmin = userEmail === "godfireprobusiness@gmail.com";
    
    const tickets = isAdmin 
      ? await storage.getAllTickets() 
      : await storage.getTickets(req.user.claims.sub);
    res.json(tickets);
  });

  app.post(api.tickets.create.path, isAuthenticated, async (req: any, res) => {
    try {
      const input = api.tickets.create.input.parse({ ...req.body, userId: req.user.claims.sub });
      const ticket = await storage.createTicket(input);
      res.status(201).json(ticket);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({
          message: err.errors[0].message,
          field: err.errors[0].path.join('.'),
        });
      }
      throw err;
    }
  });

  app.get(api.tickets.get.path, isAuthenticated, async (req: any, res) => {
    const ticket = await storage.getTicket(Number(req.params.id));
    if (!ticket) return res.status(404).json({ message: "Ticket not found" });
    
    // Authorization check: User owns ticket OR is admin
    const userEmail = req.user?.claims?.email;
    const isAdmin = userEmail === "godfireprobusiness@gmail.com";

    if (ticket.userId !== req.user.claims.sub && !isAdmin) {
      return res.status(403).json({ message: "Forbidden" });
    }
    
    res.json(ticket);
  });

  // Ticket Messages
  app.get(api.ticketMessages.list.path, isAuthenticated, async (req: any, res) => {
    const ticketId = Number(req.params.ticketId);
    const ticket = await storage.getTicket(ticketId);
    if (!ticket) return res.status(404).json({ message: "Ticket not found" });

    const userEmail = req.user?.claims?.email;
    const isAdmin = userEmail === "godfireprobusiness@gmail.com";
    if (ticket.userId !== req.user.claims.sub && !isAdmin) return res.status(403).json({ message: "Forbidden" });

    const messages = await storage.getTicketMessages(ticketId);
    res.json(messages);
  });

  app.post(api.ticketMessages.create.path, isAuthenticated, async (req: any, res) => {
    const ticketId = Number(req.params.ticketId);
    const ticket = await storage.getTicket(ticketId);
    if (!ticket) return res.status(404).json({ message: "Ticket not found" });

    const userEmail = req.user?.claims?.email;
    const isAdmin = userEmail === "godfireprobusiness@gmail.com";
    if (ticket.userId !== req.user.claims.sub && !isAdmin) return res.status(403).json({ message: "Forbidden" });

    try {
      const input = api.ticketMessages.create.input.parse(req.body);
      const message = await storage.createTicketMessage({
        ticketId,
        userId: req.user.claims.sub,
        message: input.message
      });
      res.status(201).json(message);
    } catch (err) {
       if (err instanceof z.ZodError) {
        return res.status(400).json({
          message: err.errors[0].message,
          field: err.errors[0].path.join('.'),
        });
      }
      throw err;
    }
  });

  // Seed Data
  await seedDatabase();

  return httpServer;
}

async function seedDatabase() {
  const products = await storage.getProducts();
  if (products.length === 0) {
    // VPS Plans
    await storage.createProduct({
      name: "Starter VPS",
      type: "vps",
      price: "₹450/mo",
      description: "Perfect for small bots and testing.",
      features: ["2 vCPU", "4GB RAM", "50GB NVMe Storage", "1TB Bandwidth"]
    });
    await storage.createProduct({
      name: "Standard VPS",
      type: "vps",
      price: "₹850/mo",
      description: "Balanced performance for web servers.",
      features: ["4 vCPU", "8GB RAM", "100GB NVMe Storage", "2TB Bandwidth"]
    });
    await storage.createProduct({
      name: "Pro VPS",
      type: "vps",
      price: "₹1,500/mo",
      description: "For serious hosting needs.",
      features: ["8 vCPU", "16GB RAM", "200GB NVMe Storage", "Unmetered Bandwidth"]
    });
    await storage.createProduct({
      name: "Extreme VPS",
      type: "vps",
      price: "₹2,800/mo",
      description: "Maximum power for high-demand apps.",
      features: ["16 vCPU", "32GB RAM", "500GB NVMe Storage", "Unmetered Bandwidth"]
    });
    
    // Minecraft Plans
    await storage.createProduct({
      name: "Grass Plan",
      type: "minecraft",
      price: "₹150/mo",
      description: "Starter plan for small groups.",
      features: ["2GB RAM", "Unlimited Slots", "NVMe Storage", "DDoS Protection"]
    });
    await storage.createProduct({
      name: "Stone Plan",
      type: "minecraft",
      price: "₹350/mo",
      description: "Solid performance for mid-sized servers.",
      features: ["4GB RAM", "Unlimited Slots", "NVMe Storage", "Premium Network"]
    });
    await storage.createProduct({
      name: "Iron Plan",
      type: "minecraft",
      price: "₹650/mo",
      description: "Enhanced power for community servers.",
      features: ["8GB RAM", "Unlimited Slots", "NVMe Storage", "Priority Support"]
    });
    await storage.createProduct({
      name: "Diamond Plan",
      type: "minecraft",
      price: "₹1,200/mo",
      description: "High performance for large servers.",
      features: ["16GB RAM", "Dedicated Thread", "NVMe Storage", "Premium Support"]
    });
  }
}
