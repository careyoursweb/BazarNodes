import { db } from "./db";
import {
  products, orders, tickets, ticketMessages,
  type Product, type Order, type Ticket, type TicketMessage,
  insertProductSchema, insertOrderSchema, insertTicketSchema, insertTicketMessageSchema
} from "@shared/schema";
import { eq, desc } from "drizzle-orm";
import { z } from "zod";

export interface IStorage {
  // Products
  getProducts(): Promise<Product[]>;
  getProduct(id: number): Promise<Product | undefined>;
  createProduct(product: z.infer<typeof insertProductSchema>): Promise<Product>;

  // Orders
  getOrders(userId: string): Promise<Order[]>;
  createOrder(order: z.infer<typeof insertOrderSchema>): Promise<Order>;

  // Tickets
  getTickets(userId: string): Promise<Ticket[]>;
  getAllTickets(): Promise<Ticket[]>;
  getTicket(id: number): Promise<Ticket | undefined>;
  createTicket(ticket: z.infer<typeof insertTicketSchema>): Promise<Ticket>;
  
  // Ticket Messages
  getTicketMessages(ticketId: number): Promise<TicketMessage[]>;
  createTicketMessage(message: z.infer<typeof insertTicketMessageSchema>): Promise<TicketMessage>;
}

export class DatabaseStorage implements IStorage {
  // Products
  async getProducts(): Promise<Product[]> {
    return await db.select().from(products);
  }

  async getProduct(id: number): Promise<Product | undefined> {
    const [product] = await db.select().from(products).where(eq(products.id, id));
    return product;
  }

  async createProduct(product: z.infer<typeof insertProductSchema>): Promise<Product> {
    const [newProduct] = await db.insert(products).values(product as any).returning();
    return newProduct;
  }

  // Orders
  async getOrders(userId: string): Promise<Order[]> {
    return await db.select().from(orders).where(eq(orders.userId, userId));
  }

  async createOrder(order: z.infer<typeof insertOrderSchema>): Promise<Order> {
    const [newOrder] = await db.insert(orders).values(order).returning();
    return newOrder;
  }

  // Tickets
  async getTickets(userId: string): Promise<Ticket[]> {
    return await db.select().from(tickets).where(eq(tickets.userId, userId)).orderBy(desc(tickets.createdAt));
  }

  async getAllTickets(): Promise<Ticket[]> {
    return await db.select().from(tickets).orderBy(desc(tickets.createdAt));
  }

  async getTicket(id: number): Promise<Ticket | undefined> {
    const [ticket] = await db.select().from(tickets).where(eq(tickets.id, id));
    return ticket;
  }

  async createTicket(ticket: z.infer<typeof insertTicketSchema>): Promise<Ticket> {
    const [newTicket] = await db.insert(tickets).values(ticket).returning();
    return newTicket;
  }

  // Ticket Messages
  async getTicketMessages(ticketId: number): Promise<TicketMessage[]> {
    return await db.select().from(ticketMessages).where(eq(ticketMessages.ticketId, ticketId)).orderBy(ticketMessages.createdAt);
  }

  async createTicketMessage(message: z.infer<typeof insertTicketMessageSchema>): Promise<TicketMessage> {
    const [newMessage] = await db.insert(ticketMessages).values(message).returning();
    return newMessage;
  }
}

export const storage = new DatabaseStorage();
